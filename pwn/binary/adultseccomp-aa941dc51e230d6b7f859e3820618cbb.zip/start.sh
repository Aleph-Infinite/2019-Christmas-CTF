#!/bin/sh
timeout 10 /home/howdays/problem

