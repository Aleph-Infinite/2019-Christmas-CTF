<?php
error_reporting(0);
session_start();

$admin_pw = '';
$flag = '';

function create_db($dbname) {
    global $admin_pw, $flag;
    $dbname = 'dynamic_'.$dbname;

    $db = new mysqli('localhost', 'admin', 'password', 'mysql');
    $db->query("create database {$dbname};");
    $db->close();

    $db = new mysqli('localhost', 'admin', 'password', $dbname);
    $db->query("create table users (id varchar(32), pw varchar(32), note varchar(256));");
    $db->query("insert into users values ('admin', '{$admin_pw}', '{$flag}');");
    $db->query("insert into users values ('guest', 'guest', 'im guest');");
    $db->close();

    return  $dbname;
}

if(!$_SESSION['dbname']) {
    $dbname = create_db(md5(random_bytes(50)));
    $db = new mysqli('localhost', 'admin', 'password', $dbname);
    if($db) $_SESSION['dbname'] = $dbname;
}
else {
    $db = new mysqli('localhost', 'admin', 'password', $_SESSION['dbname']);
}