<?php
error_reporting(0);
session_start();
require_once 'config.php';
require_once 'function.php';

$origin = get_origin_structure($db);
$table = $origin['table'];
$column = $origin['column'];
$data = $origin['data'];

$id = anti_sqli($_POST['id']);
$pw = anti_sqli($_POST['pw']);
$retval = ['result' => false, 'message' => 'Failed.'];

$sql = "select * from {$table} where {$column['id']}='{$id}' and {$column['pw']}='{$pw}';";
if(!$result = $db->query($sql)) {
    $retval['message'] = 'query error';
    die(json_encode($retval));
}

if($fetch = $result->fetch_array(MYSQLI_NUM)) {
    $retval['result'] = true;
    $retval['message'] = "Hello, {$fetch[0]}";

    if($fetch[0] == 'admin') {
        $retval['message'] .= "\nCan you read my note? zz";
    }
    else {
        $retval['message'] .= "\nnote : {$fetch[2]}";
    }
}

clean_structure($db, $origin);
echo json_encode($retval);